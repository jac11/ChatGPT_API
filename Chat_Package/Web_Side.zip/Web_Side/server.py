import http.server
import socketserver
import webbrowser
DIRECTORY = "/Chat_Package/Web_Side/"
with open('Chat_Package/Web_Side/.port','r') as port:
    port = int(port.read())   
Handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("127.0.0.1", port), Handler) as httpd:
        url = "http://127.0.0.1:"+str(port)+DIRECTORY
        webbrowser.open_new(url)
        httpd.serve_forever()   
