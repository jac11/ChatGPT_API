import http.server
import socketserver
import webbrowser
DIRECTORY = "Chat_Package/Chat_Web/"
with open('Chat_Package/Chat_Web/.port','r') as port:
    port = int(port.read())
def __init__(DIRECTORY) :
     super.__init__(directory=DIRECTORY)    
Handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("127.0.0.1", port), Handler) as httpd:
    url = "http://127.0.0.1:"+str(port)+DIRECTORY
    webbrowser.open_new_tab(url)
    httpd.serve_forever()
    
